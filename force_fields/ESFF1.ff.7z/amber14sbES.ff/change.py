#coded by Junxi Mu
INPUT_NAME = "AB40.pdb"
OUTPUT_NAME = "./AB40_rename.pdb"

from Bio import PDB

Non_Polar = [
    'ALA','VAL','LEU','ILE','PHE','MET','PRO','TRP','NME','ACE'
]
NP = ['A','V','L','I','F','M','P','W','X']

resi = {
    'ALA':'AL','ARG':'AR','ASN':'AN','ASP':'AP',
    'CYS':'CY','CYX':'CY','CYM':'CY',
    'GLN':'GN','GLU':'GU','GLY':'GY',
    'HIS':'HE','HID':'HD',"HIP":'HP','HIE':'HE',
    'ILE':'IL','LEU':'LE','LYS':'LY',
    'MET':'ME','PHE':'PE','PRO':'PR',
    'SER':'SE','THR':'TH','TRP':'TR',
    'TYR':'TY','VAL':'VA',
    'TPO':'TH'
    }
res = []
for value in resi.keys():
    res.append(value)



Residue_THREE_TO_ONE = {
    'ALA':'A','ARG':'R','ASN':'N','ASP':'D',
    'CYS':'C','CYX':'C','CYM':'C',
    'GLN':'Q','GLU':'E','GLY':'G',
    'HIS':'H','HID':'H',"HIP":'H','HIE':'H',
    'ILE':'I','LEU':'L','LYS':'K',
    'MET':'M','PHE':'F','PRO':'P',
    'SER':'S','THR':'T','TRP':'W',
    'TYR':'Y','VAL':'V',
    'TPO':'T','NME':'X','ACE':'X',
}
unchange = ['M','C','W']
Residue_one = []
for keys in Residue_THREE_TO_ONE.keys():
    Residue_one.append(keys)

fread = open(INPUT_NAME,"r")
seq = ""
seq_tag = -1
for line in fread.readlines():
    data = line.split()
    if(data[0]=="ATOM"):
        if(seq_tag==-1):
            seq_tag = data[4]
            try:
                seq = seq + str(Residue_THREE_TO_ONE[data[3]])
            except:
                print("Error! Unkown residue type:"+str(data[3]))
                fread.close()
                quit()
        elif(seq_tag == data[4]):
            pass
        else:
            seq_tag = data[4]
            try:
                seq = seq + str(Residue_THREE_TO_ONE[data[3]])
            except:
                print("Error! Unkown residue type:"+str(data[3]))
                fread.close()
                quit()
fread.close()

TAG = []
for i in range(0,len(seq)-1):
    if(i==0 or seq[i] in unchange):
        TAG.append(0)
    elif(seq[i-1] in NP and seq[i+1] in NP):
        TAG.append(1)
    elif(seq[i-1] in NP and seq[i+1] not in NP):
        TAG.append(2)
    elif(seq[i-1] not in NP and seq[i+1] in NP):
        TAG.append(3)
    else:
        TAG.append(4)
TAG.append(-1)

i=0
tmp_res = 0
tag_num = -1

fread = open(INPUT_NAME,"r")
fwrite = open(OUTPUT_NAME,"w")
for line in fread.readlines():
    data = line.split()
    if(data[0] == "ATOM"):
        if(tag_num==-1):
            tag_num = 0
            tmp_res = data[4]
        if(data[3] in res):
            if(data[4] == tmp_res):
                if(TAG[tag_num]==0):
                    if(data[3]=="ILE" and data[2]=="CD1"):
                        line = line.replace(data[2],"CD ")
                    fwrite.write(line)
                elif(TAG[tag_num]==-1):
                    line = line.replace(" O  "," OC1")
                    line = line.replace(" OXT"," OC2")
                    fwrite.write(line)
                else:
                    if(data[3]=="ILE" and data[2] == "CD1"):
                        line = line.replace(data[2],"CD ")
                    fwrite.write(line.replace(data[3],resi[data[3]]+str(TAG[tag_num])))
            else:
                tag_num = tag_num+1
                tmp_res = data[4]
                if(TAG[tag_num]==0):
                    fwrite.write(line)
                elif(TAG[tag_num]==-1):
                    line = line.replace(" O  "," OC1")
                    line = line.replace(" OXT"," OC2")
                    fwrite.write(line)
                else:
                    fwrite.write(line.replace(data[3],resi[data[3]]+str(TAG[tag_num])))
        else:
            print("Error: Unkown residue type!\nResidue name: "+str(data[3]))
            quit()
    else:
        fwrite.write(line)

fread.close()
fwrite.close()
