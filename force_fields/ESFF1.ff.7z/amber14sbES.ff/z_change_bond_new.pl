#!/usr/bin/perl
die "Usage: perl change_bond_new.pl Old_ffbond New_ffbond\n" if @ARGV != 2;

@CX = qw/CAL1 CAL2 CAL3 CAL4 CAR1 CAR2 CAR3 CAR4 CAN1 CAN2 CAN3 CAN4 CAP1 CAP2 CAP3 CAP4 CCYS CGN1 CGN2 CGN3 CGN4 CGU1 CGU2 CGU3 CGU4 CGY1 CGY2 CGY3 CGY4 CHI1 CHI2 CHI3 CHI4 CIL1 CIL2 CIL3 CIL4 CLE1 CLE2 CLE3 CLE4 CLY1 CLY2 CLY3 CLY4 CMET CPE1 CPE2 CPE3 CPE4 CPR1 CPR2 CPR3 CPR4 CSE1 CSE2 CSE3 CSE4 CTH1 CTH2 CTH3 CTH4 CTRP CTY1 CTY2 CTY3 CTY4 CVA1 CVA2 CVA3 CVA4 CX/;
%CA = ("CAL1"=>1, "CAL2"=>1, "CAL3"=>1, "CAL4"=>1, "CAR1"=>1, "CAR2"=>1, "CAR3"=>1, "CAR4"=>1, "CAN1"=>1, "CAN2"=>1, "CAN3"=>1, "CAN4"=>1, "CAP1"=>1, "CAP2"=>1, "CAP3"=>1, "CAP4"=>1, "CCYS"=>1,"CGN1"=>1, "CGN2"=>1, "CGN3"=>1, "CGN4"=>1, "CGU1"=>1, "CGU2"=>1, "CGU3"=>1, "CGU4"=>1, "CGY1"=>1, "CGY2"=>1, "CGY3"=>1, "CGY4"=>1, "CHI1"=>1, "CHI2"=>1, "CHI3"=>1, "CHI4"=>1, "CIL1"=>1, "CIL2"=>1, "CIL3"=>1, "CIL4"=>1, "CLE1"=>1, "CLE2"=>1, "CLE3"=>1, "CLE4"=>1, "CLY1"=>1, "CLY2"=>1, "CLY3"=>1, "CLY4"=>1, "CMET"=>1, "CPE1"=>1, "CPE2"=>1, "CPE3"=>1, "CPE4"=>1, "CPR1"=>1, "CPR2"=>1, "CPR3"=>1, "CPR4"=>1, "CSE1"=>1, "CSE2"=>1, "CSE3"=>1, "CSE4"=>1, "CTH1"=>1, "CTH2"=>1, "CTH3"=>1, "CTH4"=>1, "CTRP"=>1, "CTY1"=>1, "CTY2"=>1, "CTY3"=>1, "CTY4"=>1, "CVA1"=>1, "CVA2"=>1, "CVA3"=>1, "CVA4"=>1);

open IN,  "< $ARGV[0]" or die $!;
open OUT, "> $ARGV[1]" or die $!;

my @lines;
my $i;

$i = 0;
while(<IN>){
	chomp;
	$lines[$i] = $_;
	$i++;
}
close IN;

my $flag_bond = 0;
my $flag_constraint = 0;
my $flag_angle = 0;
my $flag_dihedral = 0;
my $flag_improper_dihedral = 0;

for($i = 0; $i <= $#lines; $i++){
	if($lines[$i] =~ /\[ bondtypes \]/ and $lines[$i+1] =~ /^;\s+i\s+j/){
		$flag_bond = $i+1;
	}
	elsif($lines[$i] =~ /\[ constrainttypes \]/){
		$flag_constraint = $i;
	}
	elsif($lines[$i] =~ /\[ angletypes \]/ and $lines[$i+1] =~ /^;\s+i\s+j/){
		$flag_angle = $i+1;
	}
	elsif($lines[$i] =~ /\[ dihedraltypes \] ;/ and $lines[$i+1] =~ /^;i\s+j/){
		$flag_improper_dihedral = $i+1;
	}
	elsif($lines[$i] =~ /\[ dihedraltypes \]/ and $lines[$i+1] =~ /^;i\s+j/){
		$flag_dihedral = $i+1;
	}
}
print $flag_bond, "\t", $flag_constraint, "\t", $flag_angle, "\t", $flag_improper_dihedral, "\t", $flag_dihedral, "\n";

my $a, $b, $c, $d;
my @re1;
my @re2;
my @re3;
my @re4;
my $format = 0;

my $a1, $b1, $c1, $d1, $e1, $f1, $g1, $h1;
my $a2, $b2, $c2, $d2, $e2, $f2, $g2, $h2;
my $a3, $b3, $c3, $d3, $e3, $f3, $g3, $h3;
my $a4, $b4, $c4, $d4, $e4, $f4, $g4, $h4;

for($i = 0; $i <= $#lines; $i++){
	if($i < $flag_bond){
		print OUT $lines[$i], "\n";
	}
	elsif($i >= $flag_bond and $i < $flag_constraint){
		if($lines[$i] =~ /\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9]+)\s+([0-9\.]+)\s+([0-9\.]+)/){
			print OUT $lines[$i], "\n";
			@re1 = &replace_atom($1);
			@re2 = &replace_atom($2);
			#print @re1, "\n" if $i == 5;
			#print @re2, "\n" if $i == 5;
			foreach $a(@re1){
				foreach $b(@re2){
					unless(($a eq $1 and $b eq $2) or (exists $CA{$a} and exists $CA{$b})){
						printf OUT "  %-5s%-5s%9d%11.5f%11.1f\n", $a, $b, $3, $4, $5;
					}
				}
			}	
		}
		else{
			print OUT $lines[$i], "\n";
		}
	}
	elsif($i >= $flag_constraint and $i < $flag_angle){
		print OUT $lines[$i], "\n"
	}
	elsif($i >= $flag_angle and $i < $flag_improper_dihedral){
		#					$1			$2			 $3		  $4		  $5		  $6
		if($lines[$i] =~ /([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9]+)\s+([0-9\.]+)\s+([0-9\.]+)/){
			print OUT $lines[$i], "\n";
			@re1 = &replace_atom($1);
			@re2 = &replace_atom($2);
			@re3 = &replace_atom($3);
			foreach $a(@re1){
				foreach $b(@re2){
					foreach $c(@re3){
						unless(($a eq $1 and $b eq $2 and $c eq $3) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$a} and exists $CA{$c})){
							printf OUT "%-5s%-5s%-5s%10d%10.3f%12.3f\n", $a, $b, $c, $4, $5, $6;
						}
					}
				}
			}
		}
		else{
			print OUT $lines[$i], "\n";
		}
	}
	elsif($i >= $flag_dihedral){
		#						 $1			  $2			$3			  $4		   $5		   $6		    $7		     $8
		if($lines[$i] =~ /\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9]+)\s+([0-9\.]+)\s+([0-9\.-]+)\s+([0-9]+)/){
			$a1 = $1;
			$b1 = $2;
			$c1 = $3;
			$d1 = $4;
			$e1 = $5;
			$f1 = $6;
			$g1 = $7;
			$h1 = $8;
			#print "$1 $2 $3 $4 $5 $6 $7 $8\n" if $i == 5008;
			@re1 = &replace_atom($1);
			@re2 = &replace_atom($2);
			@re3 = &replace_atom($3);
			@re4 = &replace_atom($4);
			if($lines[$i+1] =~ /\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9]+)\s+([0-9\.]+)\s+([0-9\.-]+)\s+([0-9]+)/){
				$a2 = $1;
				$b2 = $2;
				$c2 = $3;
				$d2 = $4;
				$e2 = $5;
				$f2 = $6;
				$g2 = $7;
				$h2 = $8;
				if($a1 eq $a2 and $b1 eq $b2 and $c1 eq $c2 and $d1 eq $d2){
					if($lines[$i+2] =~ /\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9]+)\s+([0-9\.]+)\s+([0-9\.-]+)\s+([0-9]+)/){
						$a3 = $1;
						$b3 = $2;
						$c3 = $3;
						$d3 = $4;
						$e3 = $5;
					   	$f3 = $6;
						$g3 = $7;
						$h3 = $8;
						if($a1 eq $a3 and $b1 eq $b3 and $c1 eq $c3 and $d1 eq $d3){
							if($lines[$i+3] =~ /\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9]+)\s+([0-9\.]+)\s+([0-9\.-]+)\s+([0-9]+)/){
								$a4 = $1;
								$b4 = $2;
								$c4 = $3;
								$d4 = $4;
								$e4 = $5;
								$f4 = $6;
								$g4 = $7;
								$h4 = $8;
								if($a1 eq $a4 and $b1 eq $b4 and $c1 eq $c4 and $d1 eq $d4){
									print OUT $lines[$i], "\n";
									print OUT $lines[$i+1], "\n";
									print OUT $lines[$i+2], "\n";
									print OUT $lines[$i+3], "\n";
									$i += 3;
									foreach $a(@re1){
										foreach $b(@re2){
											foreach $c(@re3){
												foreach $d(@re4){
													unless(($a eq $a1 and $b eq $b1 and $c eq $c1 and $d eq $d1) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
														printf OUT " %-5s%-5s%-5s%-5s%3d%12.1f%13.5f%6d\n", $a, $b, $c, $d, $e1, $f1, $g1, $h1;
														#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e2, $f2, $g2, $h2;
														#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e3, $f3, $g3, $h3;
														#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e4, $f4, $g4, $h4;
													}
												}
											}
										}
									}
								}
								else{
									print OUT $lines[$i], "\n";
									print OUT $lines[$i+1], "\n";
									print OUT $lines[$i+2], "\n";
									$i += 2;
									foreach $a(@re1){
										foreach $b(@re2){
											foreach $c(@re3){
												foreach $d(@re4){
													unless(($a eq $a1 and $b eq $b1 and $c eq $c1 and $d eq $d1) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
														printf OUT " %-5s%-5s%-5s%-5s%3d%12.1f%13.5f%6d\n", $a, $b, $c, $d, $e1, $f1, $g1, $h1;
														#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e2, $f2, $g2, $h2;
														#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e3, $f3, $g3, $h3;
													}
												}
											}
										}
									}
								}
							}
							else{
								print OUT $lines[$i], "\n";
								print OUT $lines[$i+1], "\n";
								print OUT $lines[$i+2], "\n";
								$i += 2;
								foreach $a(@re1){
									foreach $b(@re2){
										foreach $c(@re3){
											foreach $d(@re4){
												unless(($a eq $a1 and $b eq $b1 and $c eq $c1 and $d eq $d1) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
													printf OUT " %-5s%-5s%-5s%-5s%3d%12.1f%13.5f%6d\n", $a, $b, $c, $d, $e1, $f1, $g1, $h1;
													#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e2, $f2, $g2, $h2;
													#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e3, $f3, $g3, $h3;
												}
											}
										}
									}
								}
							}
						}
						else{
							print OUT $lines[$i], "\n";
							print OUT $lines[$i+1], "\n";
							$i += 1;
							foreach $a(@re1){
								foreach $b(@re2){
									foreach $c(@re3){
										foreach $d(@re4){
											unless(($a eq $a1 and $b eq $b1 and $c eq $c1 and $d eq $d1) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
												printf OUT " %-5s%-5s%-5s%-5s%3d%12.1f%13.5f%6d\n", $a, $b, $c, $d, $e1, $f1, $g1, $h1;
												#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e2, $f2, $g2, $h2; 
											}
										}
									}
								}
							}	
						}
					}
					else{
						print OUT $lines[$i], "\n";
						print OUT $lines[$i+1], "\n";
						$i += 1;
						foreach $a(@re1){
							foreach $b(@re2){
								foreach $c(@re3){
									foreach $d(@re4){
										unless(($a eq $a1 and $b eq $b1 and $c eq $c1 and $d eq $d1) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
											printf OUT " %-5s%-5s%-5s%-5s%3d%12.1f%13.5f%6d\n", $a, $b, $c, $d, $e1, $f1, $g1, $h1;
											#printf OUT "%8s%9s%9s%9s%6d%13.6f%13.6f%6d\n", $a, $b, $c, $d, $e2, $f2, $g2, $h2;
										}
									}
								}
							}
						}
					}
				}
				else{
					print OUT $lines[$i], "\n";
					foreach $a(@re1){
						foreach $b(@re2){
							foreach $c(@re3){
								foreach $d(@re4){
									unless(($a eq $a1 and $b eq $b1 and $c eq $c1 and $d eq $d1) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
										printf OUT " %-5s%-5s%-5s%-5s%3d%12.1f%13.5f%6d\n", $a, $b, $c, $d, $e1, $f1, $g1, $h1;
									}
								}
							}
						}
					}
				}	
			}
			else{
				print OUT $lines[$i], "\n";
				foreach $a(@re1){
					foreach $b(@re2){
						foreach $c(@re3){
							foreach $d(@re4){
								unless(($a eq $a1 and $b eq $b1 and $c eq $c1 and $d eq $d1) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
									printf OUT " %-5s%-5s%-5s%-5s%3d%12.1f%13.5f%6d\n", $a, $b, $c, $d, $e1, $f1, $g1, $h1;
								}
							}
						}
					}
				}
			}
		}
		else{
			print OUT $lines[$i], "\n";
		}
	}
	elsif($i >= $flag_improper_dihedral and $i < $flag_dihedral){
		#						$1			$2			$3			$4		  $5		  $6		   $7		  $8
		if($lines[$i] =~ /([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9A-Z]+)\s+([0-9]+)\s+([0-9\.]+)\s+([0-9\.-]+)\s+([0-9]+)/){
			print OUT $lines[$i], "\n";
			@re1 = &replace_atom($1);
			@re2 = &replace_atom($2);
			@re3 = &replace_atom($3);
			@re4 = &replace_atom($4);
			foreach $a(@re1){
				foreach $b(@re2){
					foreach $c(@re3){
						foreach $d(@re4){
							unless(($a eq $1 and $b eq $2 and $c eq $3 and $d eq $4) or (exists $CA{$a} and exists $CA{$b}) or (exists $CA{$b} and exists $CA{$c}) or (exists $CA{$c} and exists $CA{$d}) or (exists $CA{$a} and exists $CA{$c}) or (exists $CA{$b} and exists $CA{$d})){
								printf OUT "%-5s%-5s%-5s%-5s%6d%12.2f%12.5f%6d\n", $a, $b, $c, $d, $5, $6, $7, $8;
							}
						}
					}
				}
			}
		}	   
		else{   
			print OUT $lines[$i], "\n";
		}
	}
}


sub replace_atom{
	my @replace;
	my $atom;
	($atom) = @_;
	
	if($atom eq "CX"){
		@replace = @CX;
	}
	else{
		@replace = ($atom);
	}
	
	return @replace;
}
