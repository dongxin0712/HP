#!/usr/bin/perl
#This script is used to convert AMBER cmap to GROMACS cmap
use warnings;
use strict;

open IN,  "< $ARGV[0]" or die $!;
open OUT, "> $ARGV[1]" or die $!;

print OUT "[ cmaptypes ]\n\n"; 
my $res;
my $mark;
my $atom;
my $temp;
my $num;
my $i;

while(<IN>){
	chomp;
	if(/%FLAG ([A-Z]+)_MAP_?([0-9]+)?/){
		$res = $1;
		$mark = $2;
		$num = 1;
		if($mark){
			if($mark eq "11"){
				$mark = 1;
			}
			elsif($mark eq "12"){
				$mark = 2;
			}
			elsif($mark eq "21"){
				$mark = 3;
			}
			elsif($mark eq "22"){
				$mark = 4;
			}
		}
		else{
			$mark = "";
		}
		$atom = &ChangeResName($res.$mark);
		printf OUT "C N C%s C N 1 24 24\\\n", $atom;
	}
	elsif(/%FORMAT/){
		next;
	}
	else{
		#print $_, "\n";
		for($i = 0; $i <= 70; $i+=9){
			$temp = substr($_, $i, 9);
			$temp =~ s/\s//g;
			#print $temp, " ";
			if($num % 10 == 0){
				printf OUT "%.5f\\\n", $temp*4.1858518;
				$num++;
			}
			else{
				if($num == 576){
					printf OUT "%.5f\n\n", $temp*4.1858518;
					$num++;
				}
				else{
					printf OUT "%.5f ", $temp*4.1858518;
					$num++;
				}
			}
		}
		#print "\n";
	}
}
#print $num, "\n";

sub ChangeResName{
	my ($r) = @_;

	my %res_table=(
		"ALA1" => "AL1", "ALA2" => "AL2", "ALA3" => "AL3", "ALA4" => "AL4",
		"ARG1" => "AR1", "ARG2" => "AR2", "ARG3" => "AR3", "ARG4" => "AR4",
		"ASN1" => "AN1", "ASN2" => "AN2", "ASN3" => "AN3", "ASN4" => "AN4",
		"ASP1" => "AP1", "ASP2" => "AP2", "ASP3" => "AP3", "ASP4" => "AP4",
		"CYS1" => "CYS", "CYS2" => "CYS", "CYS3" => "CYS", "CYS4" => "CYS",
		"GLN1" => "GN1", "GLN2" => "GN2", "GLN3" => "GN3", "GLN4" => "GN4",
		"GLU1" => "GU1", "GLU2" => "GU2", "GLU3" => "GU3", "GLU4" => "GU4",
		"GLY1" => "GY1", "GLY2" => "GY2", "GLY3" => "GY3", "GLY4" => "GY4",
		"HIS1" => "HI1", "HIS2" => "HI2", "HIS3" => "HI3", "HIS4" => "HI4",
		"ILE1" => "IL1", "ILE2" => "IL2", "ILE3" => "IL3", "ILE4" => "IL4",
		"LEU1" => "LE1", "LEU2" => "LE2", "LEU3" => "LE3", "LEU4" => "LE4",
		"LYS1" => "LY1", "LYS2" => "LY2", "LYS3" => "LY3", "LYS4" => "LY4",
		"MET1" => "MET", "MET2" => "MET", "MET3" => "MET", "MET4" => "MET",
		"PHE1" => "PE1", "PHE2" => "PE2", "PHE3" => "PE3", "PHE4" => "PE4",
		"PRO1" => "PR1", "PRO2" => "PR2", "PRO3" => "PR3", "PRO4" => "PR4",
		"SER1" => "SE1", "SER2" => "SE2", "SER3" => "SE3", "SER4" => "SE4",
		"THR1" => "TH1", "THR2" => "TH2", "THR3" => "TH3", "THR4" => "TH4",
		"TRP1" => "TRP", "TRP2" => "TRP", "TRP3" => "TRP", "TRP4" => "TRP",
		"TYR1" => "TY1", "TYR2" => "TY2", "TYR3" => "TY3", "TYR4" => "TY4",
		"VAL1" => "VA1", "VAL2" => "VA2", "VAL3" => "VA3", "VAL4" => "VA4",
	);

	if(exists $res_table{$r}){
		return $res_table{$r};
	}
	else{
		return $r;
	}
}

