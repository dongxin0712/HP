#!/usr/bin/perl

open IN, "<$ARGV[0]" or die $!;
open OUT,">$ARGV[1]" or die $!;

@CX = qw/CAL1 CAL2 CAL3 CAL4 CAR1 CAR2 CAR3 CAR4 CAN1 CAN2 CAN3 CAN4 CAP1 CAP2 CAP3 CAP4 CCYS CGN1 CGN2 CGN3 CGN4 CGU1 CGU2 CGU3 CGU4 CGY1 CGY2 CGY3 CGY4 CHI1 CHI2 CHI3 CHI4 CIL1 CIL2 CIL3 CIL4 CLE1 CLE2 CLE3 CLE4 CLY1 CLY2 CLY3 CLY4 CMET CPE1 CPE2 CPE3 CPE4 CPR1 CPR2 CPR3 CPR4 CSE1 CSE2 CSE3 CSE4 CTH1 CTH2 CTH3 CTH4 CTRP CTY1 CTY2 CTY3 CTY4 CVA1 CVA2 CVA3 CVA4 CX/;
@name = qw/00 AA BB CC DD/;

while(<IN>){
	print OUT $_;
	if(/CX/){
		if(/([A-Z0-9]+)(\s+)([0-9])(\s+)(.+)/){
			#print $1,";",$_;
			if($1 eq "CX"){
				@AA = @CX;
				#print @AA, "\n";
			}
			else{
				@AA = ($1);
			}
			foreach $a(@AA){
				unless($a eq $1){
					print OUT  $a, $2, $3, $4, $5, "\n";
				}
			}
		}
	}
}	
